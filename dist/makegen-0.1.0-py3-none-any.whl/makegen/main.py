"""
makegen: Makefile Generator

This can generate makefiles using Python
"""
def main() -> None:
    print("Hello, World!")